# Windows DFU driver

... is in the dfu-prog-xxxx subdirectory.

# maintenance

## bundling OS X libs

    dylibbundler -od -b -x ./dfu-programmer.osx
