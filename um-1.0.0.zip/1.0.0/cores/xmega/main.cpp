#include <Arduino.h>

#if defined(USB_SERIAL)
extern "C" {
  #include "USB_usb.h"
  #include "USB_usb_xmega.h"
  USB_ENDPOINTS(4); // number of endpoints to create table for!
}
#endif

// System Clocks initialization
void system_clocks_init(void)
{
	unsigned char n,s;
	// Save interrupts enabled/disabled state
	s=SREG;
	// Disable interrupts
	asm("cli");

	#if F_CPU==8000000
	// External 14745.600 kHz oscillator initialization
	OSC.XOSCCTRL=OSC_FRQRANGE_12TO16_gc | OSC_XOSCSEL_XTAL_16KCLK_gc;
	// Enable the external oscillator
	OSC.CTRL|=OSC_XOSCEN_bm;

	// System clock prescaler A division factor: 1
	// System clock prescalers B & C division factors: B:1, C:1
	// ClkPer4: 14745.600 kHz
	// ClkPer2: 14745.600 kHz
	// ClkPer:  14745.600 kHz
	// ClkCPU:  14745.600 kHz
	n=(CLK.PSCTRL & (~(CLK_PSADIV_gm | CLK_PSBCDIV1_bm | CLK_PSBCDIV0_bm))) |
		CLK_PSADIV_1_gc | CLK_PSBCDIV_1_1_gc;
	CCP=CCP_IOREG_gc;
	CLK.PSCTRL=n;

	// Wait for the external oscillator to stabilize
	while ((OSC.STATUS & OSC_XOSCRDY_bm)==0);

	// Select the system clock source: External Osc. or Clock
	n=(CLK.CTRL & (~CLK_SCLKSEL_gm)) | CLK_SCLKSEL_XOSC_gc;
	CCP=CCP_IOREG_gc;
	CLK.CTRL=n;

	// Disable the unused oscillators: 2 MHz, 32 MHz, internal 32 kHz, PLL
	OSC.CTRL&= ~(OSC_RC2MEN_bm | OSC_RC32MEN_bm | OSC_RC32KEN_bm | OSC_PLLEN_bm);

	// Peripheral Clock output: Disabled
	PORTCFG.CLKEVOUT=(PORTCFG.CLKEVOUT & (~PORTCFG_CLKOUT_gm)) | PORTCFG_CLKOUT_OFF_gc;

	#elif F_CPU==32000000
	// Internal 32 kHz RC oscillator initialization
	// Enable the internal 32 kHz RC oscillator
	OSC.CTRL|=OSC_RC32KEN_bm;
	// Wait for the internal 32 kHz RC oscillator to stabilize
	while ((OSC.STATUS & OSC_RC32KRDY_bm)==0);

	// Internal 32 MHz RC oscillator initialization
	// Enable the internal 32 MHz RC oscillator
	OSC.CTRL|=OSC_RC32MEN_bm;

	// System clock prescaler A division factor: 1
	// System clock prescalers B & C division factors: B:1, C:1
	// ClkPer4: 32000.000 kHz
	// ClkPer2: 32000.000 kHz
	// ClkPer:  32000.000 kHz
	// ClkCPU:  32000.000 kHz
	n=(CLK.PSCTRL & (~(CLK_PSADIV_gm | CLK_PSBCDIV1_bm | CLK_PSBCDIV0_bm))) |
		CLK_PSADIV_1_gc | CLK_PSBCDIV_1_1_gc;
	CCP=CCP_IOREG_gc;
	CLK.PSCTRL=n;

	// Internal 32 MHz RC osc. calibration reference clock source: 32.768 kHz Internal Osc.
	OSC.DFLLCTRL&= ~(OSC_RC32MCREF_bm | OSC_RC2MCREF_bm);
	// Enable the autocalibration of the internal 32 MHz RC oscillator
	DFLLRC32M.CTRL|=DFLL_ENABLE_bm;

	// Wait for the internal 32 MHz RC oscillator to stabilize
	while ((OSC.STATUS & OSC_RC32MRDY_bm)==0);

	// Select the system clock source: 32 MHz Internal RC Osc.
	n=(CLK.CTRL & (~CLK_SCLKSEL_gm)) | CLK_SCLKSEL_RC32M_gc;
	CCP=CCP_IOREG_gc;
	CLK.CTRL=n;

	// Disable the unused oscillators: 2 MHz, external clock/crystal oscillator, PLL
	OSC.CTRL&= ~(OSC_RC2MEN_bm | OSC_XOSCEN_bm | OSC_PLLEN_bm);

	// Peripheral Clock output: Disabled
	PORTCFG.CLKEVOUT=(PORTCFG.CLKEVOUT & (~PORTCFG_CLKOUT_gm)) | PORTCFG_CLKOUT_OFF_gc;
	
	#elif F_CPU==2000000
	// Internal 32 kHz RC oscillator initialization
	// Enable the internal 32 kHz RC oscillator
	OSC.CTRL|=OSC_RC32KEN_bm;
	// Wait for the internal 32 kHz RC oscillator to stabilize
	while ((OSC.STATUS & OSC_RC32KRDY_bm)==0);

	// Internal 2 MHz RC oscillator initialization
	// Enable the internal 2 MHz RC oscillator
	OSC.CTRL|=OSC_RC2MEN_bm;

	// System clock prescaler A division factor: 1
	// System clock prescalers B & C division factors: B:1, C:1
	// ClkPer4: 2000.000 kHz
	// ClkPer2: 2000.000 kHz
	// ClkPer:  2000.000 kHz
	// ClkCPU:  2000.000 kHz
	n=(CLK.PSCTRL & (~(CLK_PSADIV_gm | CLK_PSBCDIV1_bm | CLK_PSBCDIV0_bm))) |
		CLK_PSADIV_1_gc | CLK_PSBCDIV_1_1_gc;
	CCP=CCP_IOREG_gc;
	CLK.PSCTRL=n;

	// Internal 2 MHz RC osc. calibration reference clock source: 32.768 kHz Internal Osc.
	OSC.DFLLCTRL&= ~(OSC_RC32MCREF_bm | OSC_RC2MCREF_bm);
	// Enable the autocalibration of the internal 2 MHz RC oscillator
	DFLLRC2M.CTRL|=DFLL_ENABLE_bm;

	// Wait for the internal 2 MHz RC oscillator to stabilize
	while ((OSC.STATUS & OSC_RC2MRDY_bm)==0);

	// Select the system clock source: 2 MHz Internal RC Osc.
	n=(CLK.CTRL & (~CLK_SCLKSEL_gm)) | CLK_SCLKSEL_RC2M_gc;
	CCP=CCP_IOREG_gc;
	CLK.CTRL=n;

	// Disable the unused oscillators: 32 MHz, external clock/crystal oscillator, PLL
	OSC.CTRL&= ~(OSC_RC32MEN_bm | OSC_XOSCEN_bm | OSC_PLLEN_bm);

	// Peripheral Clock output: Disabled
	PORTCFG.CLKEVOUT=(PORTCFG.CLKEVOUT & (~PORTCFG_CLKOUT_gm)) | PORTCFG_CLKOUT_OFF_gc;
	#endif

	// Restore interrupts enabled/disabled state
	SREG=s;
} // system_clocks_init()

int main(void)
{
	init();
//	Serial.begin(19200);

#if defined(USB_SERIAL)
  usb_init();
  usb_attach();
  Serial.begin(0); // ugly, but I can't figure out why it doesn't work without this...
#endif

  	system_clocks_init();
	setup();

	for (;;) {
		loop();
		if (serialEventRun) serialEventRun();
	}

	return 0;
}
