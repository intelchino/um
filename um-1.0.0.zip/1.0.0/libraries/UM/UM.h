/* UM_protocol.h - Header UM protocol for communitcation with UM module */

#ifndef _UM_H_
#define _UM_H_

#include <stdio.h>
#include <Arduino.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <util/crc16.h>
#include <stdbool.h>
#include <string.h>

#include <SPI.h>
#include <RTC.h>

#define UM_BUFF_MAX 32
#define UM_BUFF_CELL_MAX 32

#define SLEEP_PERIOD 10

#define UM_ACK 0x0f
#define UM_NAK 0xff

typedef enum RET_STATUS {
	STATUS_ERR	= -1,
	STATUS_OK	= 0,
	STATUS_SIZE_OVF,
	STATUS_ACK,
	STATUS_NAK,
	STATUS_NO_ACK
};

typedef enum TRANSMIT_STATUS {
	UM_SUCCESS = 0,
	UM_NO_DATA,
	UM_FAILED
};

typedef enum UM_STATES {
	UM_TRANCEIVER,
	UM_PROCESS,
	UM_IDLE
};

/* @structure UMPacket	UM packet store raw data for sending and receiving
 * throught UM communication.
 *
 * @member data		UM packet raw data.	
 * @member size		Size of data.
 * */
typedef struct UMPacket {
	 byte data[UM_BUFF_CELL_MAX];
	 size_t size;
};

/* @structure UMRingBuff UM ring buffer that store all UM packet ready for sending or receiving.
 *
 * @member ring		Array of UM packet.
 * @member head		Point to head of ring.
 * @member tail		Point to tail of ring.
 * @member lock		lock buffer while reading or writing
 */
typedef struct UMRingBuff {
	UMPacket ring[UM_BUFF_MAX];
	uint8_t head;
	uint8_t tail;
	bool lock; // TODO - We need priority mechanism while access this buffer

	UMRingBuff() : 
		head(0),
		tail(0),
		lock(false)
	{}
};

/* @function ApplicationCmdHandler This function is defined by user and called in UM framework to handle received UM packet in UM Rx buffer.
 * 
 * @param cmd		UM command.
 * @param payload	UM packet payload.
 * @param len		Length of payload.
 *
 * @return
 * */
void ApplicationCmdHandler(char cmd, char *payload, uint16_t len);

class UMClass{

	public:

		/* @function UMClass Class constructor
		 * 
		 * @param
		 *
		 * @return
		 */
		UMClass();

		/* @function ~UMClass Class destructor
		 * 
		 * @param
		 *
		 * @return
		 */
		~UMClass();

		/* @function begin	Start UM module, intialzie hardware
		 *
		 * @param
		 *
		 * @return
		 */
		void begin();


		/* @function pushUMMessage	Exposed function for user to send data. It just write data into UM sending buffer. UM will handler sending buffer.
		 *
		 * @param cmd		UM command	
		 * @param payload	data was send to cloud	
		 * @param len		length of payload
		 * 
		 * @return	status of writing buffer
		 *		- STATUS_SIZE_OVF
		 *		- STATUS_OK
		 */
		uint8_t pushUMMessage(uint8_t cmd, uint8_t *payload, uint16_t len);


		/* @function requestHandler() The interrupt routin handle receiving message
		 *
		 * @param
		 *
		 * @return
		 */
		void requestHandler();
			
		/* @function end	Deinitialize UM module
		 *
		 * @param
		 *
		 * @return
		 */
		void end();


		/* @function stateManager UM framework state manager that handle switching between states machine. There are three states:
		 *	UM_TRANSCEIVER	UM transmission state that carry out send/receive UM packet to/from UM module.
		 *	UM_PROCCESS		UM message processing state.
		 *	UM_IDLE			UM idle state (all task done), go to sleep after run in this state.
		 * 
		 * @param
		 *
		 * @return
		 */
		void stateManager();

	private:

		/* UM sending buffer */
		UMRingBuff *txBuff;

		/* UM receiving buffer */
		UMRingBuff *rxBuff;

		bool reqFlag;
		
		/* UM request pin */
		uint8_t nREQPin;

		/* UM Clear to Send, Clear to Request pin */	
		uint8_t CTR_CTS;

		int umCurState;
		int umPreState;

		/* @function sendUMPackage This function actually send one block of data through UM protocol.	
		 * @param packet	UM packet
		 *
		 * @return status of sending
		 *	STATUS_ERR	sending failed
		 *	STATUS_OK	sending succces
		 */
		int sendUMPacket(UMPacket packet);

		/* @function available	Check UM receiving data buffer is available or not
		 *
		 * @param
		 *
		 * @return Status of UM Rx buffer
		 * true		Data in Rx buffer is avaible
		 * false	There are no data in Rx buffer
		 */
		bool available();

		/* @function checkUMState	
		 * Check UM transmittion buffer and UM status then transmit data.
		 *
		 * @return UM status of transmition
		 *	UM_SUCCESS - transmited success.
		 *	UM_NO_DATA - have no data to transmit 
		 *	UM_FAILED - transmit failed.
		 */
		int checkUMState();

		/* @function recvUMPacket	This function is responssible for receiving UM packet from UM module. Request interrupt handler call this function.
		 *
		 * @param
		 *
		 * @return
		 */
		void recvUMPacket();



		/* @function runCmdHandler On run-time, message from UM module will automatically push into Rx buffer. At the end of user loop, this function must be called to access the buffer then pass  it to ApplicationCmdHandler for handling packet.
		 *
		 * @param
		 *
		 * @return
		 */
		void runCmdHandler();

		/* @function writeUMBuff	Write data into UM buffer.
		 *
		 * @param umBuff	The pointer to UM buffer will be written.
		 * @param data		Input data for writing to UM buffer.
		 * @param size		Size of data length.
		 *
		 * @return	Status of writing.
		 * STATUS_SIZE_OVF	Size of input data larger than UM packet maximum size.
		 * STATUS_OK		Write to UM buffer success.
		 */
		uint8_t writeUMBuff(UMRingBuff *umBuff, byte *data, size_t size);


		/* @function isCRCValid		Check CRC in UM packet is valid or not.
		 * 
		 * @param crc	Attched CRC of UM packet for reference.
		 * @param data	Data used for checking CRC.
		 * @param len	Length of data input.
		 *
		 * @return Result of CRC checking.
		 * true		CRC is valid.
		 * false	CRC is invalid.
		 */
		bool isCRCValid(uint16_t crc, uint8_t *data, uint16_t len);

		/* @function generateCRC generate CRC value for block of data
		 *
		 * @param data		Data that is used to generate CRC
		 * @param len		Length of data
		 *
		 * @return	CRC value of input data
		 */
		uint16_t generateCRC(uint8_t *data, uint16_t len);

		/* @function checkACK	checking ACK of sended message.
		 *
		 * @return
		 *  STATUS_ACK		received ACK
		 *  STATUS_NAK		received NAK
		 *  STATUS_NO_ACK	have no ACK or NAK 
		 */
		int checkACK();

		void updateUMState(int newState);
		void gotoSleep();
		void ledIndicator(uint8_t blinkCount);

};

/* @function umISR	Request pin interrupt routin.
 * 
 * @param
 *
 * @return
 */
void umISR();


/* Extern UM instance */
extern UMClass UM;

#endif
