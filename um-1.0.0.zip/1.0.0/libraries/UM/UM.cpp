#include "UM.h"

UMClass UM;



UMClass::UMClass() : txBuff(new UMRingBuff), rxBuff(new UMRingBuff)
{
	nREQPin = 10;
	CTR_CTS = 11;
}

UMClass::~UMClass()
{

}

void UMClass::begin()
{
	pinMode(nREQPin, INPUT_PULLUP);
	pinMode(CTR_CTS, INPUT_PULLUP);
	attachInterrupt(nREQPin, umISR, CHANGE);

	SPI.setClockDivider(SPI_CLOCK_DIV32);
	SPI.begin();
	SPI.attachInterrupt();

	umCurState = UM_IDLE;
	umPreState = UM_IDLE;

	reqFlag = false;
	
	pinMode(9, OUTPUT);
}

void UMClass::end() 
{
	SPI.end();
}

void UMClass::stateManager() {

	while(umCurState != UM_IDLE) {

		switch(umCurState) {
			case UM_TRANCEIVER:
				if(reqFlag) {
				/* receive UM message */
					recvUMPacket();
					reqFlag = false;
//					ledIndicator(3);
				}

				/* Send all of Tx buff to UM */
				if(checkUMState() == UM_FAILED) {
					ledIndicator(3);
					Serial.println("UM is not available");
				} else {
//					ledIndicator(5);
				}

				updateUMState(UM_PROCESS);
				break;

			case UM_PROCESS:
				/* UM process here. */
				runCmdHandler();

				/* At the end of processing could change mode to
				 * UM_TRANCEIVER or UM_IDLE.
				 */
				updateUMState(UM_IDLE);
				break;
			default:
				updateUMState(UM_IDLE);
		}
	}

	/* All task done, MCU run into sleep mode. */
	gotoSleep();
}

void UMClass::updateUMState(int newState) {
	
	umPreState = umCurState;
	umCurState = newState;
}


uint8_t UMClass::pushUMMessage(uint8_t cmd, uint8_t *payload, uint16_t len)
{

	size_t size = len + 1 + 2 + 2;//1 byte cmd, payload length, 2 bytes payload length, 2 bytes CRC 
	int ret;

	if (size > UM_BUFF_CELL_MAX)
		return STATUS_SIZE_OVF;
	uint8_t data[size];
	
	uint16_t crc = generateCRC(payload, len);
	
	data[0] = cmd;

	/* Convert crc from little-endian to big-endian then assembly it into mesage buffer */
	data[1] = (uint8_t)((len >> 8) & 0xff);
	data[2] = (uint8_t)(len & 0xff);

	/* Assembly payload */
	memcpy((data + 3), payload, len);

	/* Add CRC to end of message */
	data[size - 2] = (uint8_t)((crc >> 8) & 0xff);
	data[size - 1] = (uint8_t)(crc & 0xff);
	ret = writeUMBuff(txBuff, data, size);

	updateUMState(UM_TRANCEIVER);

	return ret;
}

/*
 * There is a protection method while access the buffer.
 */
uint8_t UMClass::writeUMBuff(UMRingBuff *umBuff, byte *data, size_t size)
{
	if (size > UM_BUFF_CELL_MAX)
		return STATUS_SIZE_OVF;

	byte i, c;

	while(umBuff->lock == true);

	/* Sending buffer released at here. 
	 * Before access the buffer, we have to lock it for protection and release it
	 * after accessing finished.
	 * */
	umBuff->lock = true;
	i = umBuff->head + 1;
	if (i >= UM_BUFF_MAX)
		i = 0;
	memcpy(umBuff->ring[i].data, data, size);
	umBuff->ring[i].size = size;
	umBuff->head = i;
		
	umBuff->lock = false;
	return STATUS_OK;
}

int UMClass::checkUMState()
{
	if(txBuff->head == txBuff->tail) 
		return UM_NO_DATA;


	while(txBuff->head != txBuff->tail) {

		uint8_t i;
		int ret;
		i = txBuff->tail + 1;
		if(i >= UM_BUFF_MAX)
			i = 0;
		
		Serial.println("---------------------------------------");
		Serial.println("MCU send message to UM");
		ret = sendUMPacket(txBuff->ring[i]);
		if( ret == STATUS_ERR) {
			return UM_FAILED;	
		} else if(ret == STATUS_NAK) {
			Serial.println("received NAK");
			//continue;
		} else if(ret == STATUS_NO_ACK) {
			Serial.println("have no ACK");
			//continue;
		} else {
			Serial.println("Received ACK");
			Serial.println("Transmission completed");
		}
		Serial.println("----------------------------------------");
		txBuff->tail = i;
	}
	return STATUS_OK;
}

int UMClass::sendUMPacket(UMPacket packet)
{
	int count = 0;
	uint8_t recv;
	/* wait for UM available to communicate */
	while(digitalRead(CTR_CTS) != HIGH);


	detachInterrupt(nREQPin);
	pinMode(nREQPin, OUTPUT);
	digitalWrite(nREQPin, LOW); // request to send message

	while(digitalRead(CTR_CTS) != LOW) { // wait for UM already to transmit
		
		delay(10);
		if(count++ >= 10) {
			//Serial.println("UM is not ready");
			pinMode(nREQPin, INPUT_PULLUP);
			attachInterrupt(nREQPin, umISR, CHANGE);
			return STATUS_ERR;
		}
	}

	for (int i = 0; i < packet.size; i++) {
		//Serial.print(packet.data[i], HEX);
		recv = SPI.transfer(packet.data[i]);
		//Serial.print(recv, HEX);
	}

	pinMode(nREQPin, INPUT_PULLUP);
	attachInterrupt(nREQPin, umISR, CHANGE);

	/* receive ACK */
	return checkACK();
}

int UMClass::checkACK() {


	uint8_t count = 0;
	uint8_t size = 0;
	byte recv;
	byte tmpBuff[UM_BUFF_CELL_MAX];
	
	/* Waiting for request signal from UM */
	while(reqFlag != true) {

		if(count++ >= 50) {
			return STATUS_NO_ACK;
		}
		delay(100);
	}

	/* Confirm UM is ready for communication */
	if (digitalRead(nREQPin) == LOW) {

		detachInterrupt(nREQPin);
		/* Inform MCU is ready to communicate */
		pinMode(CTR_CTS, OUTPUT);
		digitalWrite(CTR_CTS, LOW);

		delay(100);
		//ledIndicator(1);
		/* Transmission */
		while(digitalRead(nREQPin) == LOW) {
			recv = SPI.transfer(0x00);
			tmpBuff[size++] = recv;
		}

		digitalWrite(CTR_CTS, HIGH);
		pinMode(CTR_CTS, INPUT_PULLUP); // release CTS/RTS - transmission completed
		reqFlag = false;
		attachInterrupt(nREQPin, umISR, CHANGE);
		if(tmpBuff[0] == UM_ACK) {
			return STATUS_ACK;
		} else if(tmpBuff[0] == UM_NAK) {
			return STATUS_NAK;
		}
	}
	return STATUS_NO_ACK;

#if 0

	int count = 0;
	int last_head_position = -1;

	while(count++ < 10) {
		int position;

		if(available())	{
			position = rxBuff->head;
			if(position == last_head_position) {
				// Have no new data 
				continue;
			}
			/* Find ACK in rxBuff */
			while(position != rxBuff->tail) {
				uint8_t cmd = rxBuff->ring[position].data[0];
				if(cmd == 0x0f) {

					return STATUS_ACK;
				}else if(cmd == 0xff) {
					return STATUS_NAK;
				}else{
					if(--position < 0)
						position = 31;
				}
			}
			last_head_position = rxBuff->head;;
		}
		delay(500);
		
	}

	return STATUS_NO_ACK;
#endif
}


bool UMClass::available() 
{
	if(rxBuff->head != rxBuff->tail) {

		return true;
	}
	return false;
}

void UMClass::runCmdHandler() {
	while (UM.available()) {
		int i = rxBuff->tail + 1;
		if (i >= UM_BUFF_MAX) 
			i = 0;
		UMPacket umBuff = rxBuff->ring[i];
		rxBuff->tail = i;
		uint8_t cmd = umBuff.data[0];

		/* Ignore ACK packet */
		if ((cmd == 0x0f) || (cmd == 0xff)) {
			continue;	
		}
		uint16_t len = umBuff.data[2] | umBuff.data[1]<<8; //big endian
		char payload[len];
				
		memcpy(payload, (umBuff.data + 3), len);
		ApplicationCmdHandler(cmd, payload, len);
	}


}

void UMClass::requestHandler()
{
	if(digitalRead(nREQPin) == LOW) {
		reqFlag = true;
	}
	return;

}

void UMClass::recvUMPacket()
{
	uint8_t size = 0;
	byte recv;
	byte tmpBuff[UM_BUFF_CELL_MAX];
	
	detachInterrupt(nREQPin);
	if (digitalRead(nREQPin) == LOW) {

		pinMode(CTR_CTS, OUTPUT);
		digitalWrite(CTR_CTS, LOW);
		delay(100);
		while(digitalRead(nREQPin) == LOW) {
			recv = SPI.transfer(0x00);
			tmpBuff[size++] = recv;
		}

		/* Check cmd is an ACK of previous sending message or not */
		if((tmpBuff[0] == 0x0f) || (tmpBuff[0] == 0xff)) {
			writeUMBuff(rxBuff, tmpBuff, size);
			return;
		}

		/* Check CRC to send ACK (have not supported large data packtes yet) */	
		uint16_t len = tmpBuff[2] | tmpBuff[1]<<8;
		uint8_t *payload = &(tmpBuff[3]);
		uint16_t crc = *(payload + len)<<8 | *(payload + len + 1);

		if(isCRCValid(crc, payload, len)) {
			Serial.println("<<<<<<<<Receiced message from UM");
			/* send ACK to UM */
			SPI.transfer(0x0f);
			writeUMBuff(rxBuff, tmpBuff, size);
		} else {
			Serial.println("CRC is invalid");
			/* Send NCK to UM */
			SPI.transfer(0xff);
		}
		digitalWrite(CTR_CTS, HIGH);
		pinMode(CTR_CTS, INPUT_PULLUP); // receiver release CTS/RTS - transmission completed
	}
	attachInterrupt(nREQPin, umISR, CHANGE);
}

bool UMClass::isCRCValid(uint16_t crc, uint8_t *data, uint16_t len) 
{
	uint16_t a_crc = 0xffff; //polynomial = 0xa001

	for(int i = 0; i < len; i++) {
		a_crc = _crc16_update(a_crc, data[i]);
	}
	if(crc != a_crc) {
		return false;
	}
	return true;
}

uint16_t UMClass::generateCRC(uint8_t *data, uint16_t len) {
	uint16_t crc = 0xffff;
	for(int i = 0; i < len; i++) {
		crc = _crc16_update(crc, data[i]);
	}
	return crc;
}

void UMClass::gotoSleep() {
	
	/* TESTING CODE */
	reqFlag = false;
	Serial.println("MCU go to sleep");
	rtc.begin(SLEEP_PERIOD, 0, 0);	
	digitalWrite(9, LOW);
	attachInterrupt(nREQPin, umISR, CHANGE);

	set_sleep_mode(SLEEP_MODE_PWR_SAVE);
	sleep_enable();

	sleep_mode();

	/* wake up here */
	if(reqFlag == true) {
		/* request from UM */

		ledIndicator(1);
	}
	sleep_disable();
	rtc.end();
	digitalWrite(9, HIGH);
}

void UMClass::ledIndicator(uint8_t blinkCount) {

	for(uint8_t i = 0; i < blinkCount; i++) {
		digitalWrite(9, LOW);
		delay(200);
		digitalWrite(9, HIGH);
		delay(200);
	}
}

void umISR()
{
	UM.requestHandler();
}
