#include "pins_arduino.h"
#include "ADC.h"


ADCClass ADC;

adc_callback_t adca_callback;

ISR(ADCA_CH0_vect)
{
	adca_callback(&ADCA, ADC_CH0, adc_get_result(&ADCA, ADC_CH0));
}

ISR(ADCA_CH1_vect)
{
	adca_callback(&ADCA, ADC_CH1, adc_get_result(&ADCA, ADC_CH1));
}

ISR(ADCA_CH2_vect)
{
	adca_callback(&ADCA, ADC_CH2, adc_get_result(&ADCA, ADC_CH2));
}

ISR(ADCA_CH3_vect)
{
	adca_callback(&ADCA, ADC_CH3, adc_get_result(&ADCA, ADC_CH3));
}

ADCClass::ADCClass()
{
	adcPin = 1;
	adc = NULL;
}

ADCClass::~ADCClass()
{

}



void ADCClass::adc_set_callback(ADC_t *adc, adc_callback_t callback)
{
	if((uintptr_t)adc == (uintptr_t)&ADCA){
		adca_callback = callback;
	}
}


void ADCClass::begin(uint8_t pin, int mode)
{
	/* ADC INIT */
	if ( pin < 12 ) {
		adc = &ADCA;
	} else {
		return;
	}
	adcPin = pin;

	/* ADC configuration:
	 * - unsigned, 12-bit resolution
	 * - bandgap (1V) voltage reference
	 * - 128kHz maximum clock rate
	 * - manual conversion triggering
	 * - callback function
	 */
	/* Preserve all except conversion and resolution config */
	if ((mode == INTERRUPT) || (mode == POLLING)) {
		adc->CTRLB &= ~(ADC_CONMODE_bp | ADC_RESOLUTION_gm);
		adc->CTRLB |= ADC_RESOLUTION_12BIT_gc;
		adc->REFCTRL &= ~ADC_REFSEL_gm;
		adc->REFCTRL |= ADC_REFSEL_INT1V_gc;


		// 128K times per second with 32Mhz sys clock. That's what the mega based
		// arduinos use. No idea if that is appropriate for xmegas.
		adc->PRESCALER = ADC_PRESCALER_DIV256_gc;
		adc->REFCTRL &= ~ADC_TEMPREF_bm;// disable internal temperature ref

		/* Configure single-ended measurement on channel 0 */
		adc->CH0.CTRL = ADC_CH_INPUTMODE_SINGLEENDED_gc; 
		adc->CH0.MUXCTRL = adcPin << ADC_CH_MUXPOS_gp; 

		/* Set ADC manual conversion trigger */
		adc->CTRLB &= ~ADC_FREERUN_bm;
		adc->EVCTRL = ADC_EVACT_NONE_gc;

		adc->CH0.INTCTRL &= ~ADC_CH_INTMODE_gm;
		adc->CH0.INTCTRL |= ADC_CH_INTMODE_COMPLETE_gc;	

		if (mode == INTERRUPT) {
			/* Configure ADC channel 0:
			 * - single-ended measurement
			 * - interrupt flag set on completed conversion
			 */

			/* Assign ADC callback function */
			adc_set_callback(&ADCA, &adcHandler);

			/* Enable interrupts on ADC channel */
			adc->CH0.INTCTRL &= ~ADC_CH_INTLVL_gm;	
			adc->CH0.INTCTRL |= ADC_CH_INTLVL_LO_gc;
		} else if (mode == POLLING){

			/* Disable interrupts on ADC channel */
			adc->CH0.INTCTRL &= ~ADC_CH_INTLVL_gm;	
			adc->CH0.INTCTRL |= ADC_CH_INTLVL_OFF_gc;

			//	adc->CTRLB |= ADC_FREERUN_bm;
			adc->INTFLAGS = 0; // No interrupt on conversion complete
			adc->CH0.INTFLAGS = 1; // Strangely enough, clears IF
		}

		/* Enable the ADC */	
		adc->CTRLA |= ADC_ENABLE_bm;
	}

}

void ADCClass::end()
{
	adc->CTRLA &= ~ADC_CH0START_bm;
	adc->CTRLA &= ~ADC_ENABLE_bm;
	adc = NULL;
}

int ADCClass::readAdc()
{
	
	int pin;
	uint16_t result;

	if(adc) {
		pin = adcToChannel(adcPin);
		//adc->REFCTRL     = AREF_VCC << ADC_REFSEL_gp;
		adc->CH0.MUXCTRL = pin << ADC_CH_MUXPOS_gp; // Select pin for positive input

		adc->CTRLA |= ADC_CH0START_bm;
		adc->CH0.CTRL |= ADC_CH_START_bm; // Start conversion
		while ( 0 == (adc->CH0.INTFLAGS & ADC_CH_CHIF_bm) ); // wait for adc to finish

		adc->CH0.INTFLAGS = 1;

		result = adc->CH0RES;
	} else {
		result = -1;
	}

    return result;
}

void ADCClass::start_conversion()
{
	adc->CTRLA |= ADC_CH0START_bm; //Start conversion
}
