#ifndef _ADC_H_INCLUDED
#define _ADC_H_INCLUDED

#include <Arduino.h>


#define ADC_CH0    (1U << 0)                 /**< ADC channel 0. */
#define ADC_CH1    (1U << 1)                 /**< ADC channel 1. */
#define ADC_CH2    (1U << 2)                 /**< ADC channel 2. */
#define ADC_CH3    (1U << 3)                 /**< ADC channel 3. */



enum ADC_CONVERSION_MODE {
	POLLING,
	INTERRUPT
};

inline static ADC_CH_t *adc_get_channel(ADC_t *adc, uint8_t ch_mask)
{
	uint8_t index = 0;
	
	if(!(ch_mask & 0x03)) {
		index += 2;
		ch_mask >>= 2;
	}

	if(!(ch_mask & 0x01)) {
		index++;
	}
	return (ADC_CH_t *)(&adc->CH0 + index);
}

typedef void (*adc_callback_t)(ADC_t *adc, uint8_t ch_mask, uint16_t result);

void adcHandler(ADC_t *adc, uint8_t ch_mask, uint16_t result);


#define adc_get_result(adc, ch_mask) (adc_get_channel(adc, ch_mask)->RES)

class ADCClass {

public:
	ADCClass();
	~ADCClass();
	void begin(uint8_t pin, int mode);
	void end();
	int	readAdc();
	void start_conversion();
	
private:
	int adcPin;
	ADC_t *adc;
	void adc_set_callback(ADC_t *adc, adc_callback_t callback);

};

extern ADCClass ADC;
#endif
