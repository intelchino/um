#include "RTC.h"


RTCClass rtc;

RTCClass::RTCClass() : rtc_settings()
{

} 

RTCClass::RTCClass(const RTCSettings & init) : rtc_settings(init)
{

}

void RTCClass::begin(uint16_t period, uint16_t count, uint16_t compareValue) {

	do {
		/* Wait until RTC is not busy. */
	} while (  RTC.STATUS & RTC_SYNCBUSY_bm );

	/* Configure RTC period second. */
	RTC.PER = period;
	RTC.CNT = count;
	RTC.COMP = compareValue;
	RTC.CTRL = ( RTC.CTRL & ~RTC_PRESCALER_gm ) | RTC_PRESCALER_DIV1024_gc;

	/* Enable overflow/compare interrupt. */
	RTC.INTCTRL = ( RTC.INTCTRL & ~(RTC_OVFINTLVL_gm | RTC_COMPINTLVL_gm)) |
	              RTC_OVFINTLVL_LO_gc | RTC_COMPINTLVL_OFF_gc;

}


void RTCClass::end(){

	do {
		/* Wait until RTC is not busy. */
	} while (RTC.STATUS & RTC_SYNCBUSY_bm);


	/* Disable overflow/compare interrupt. */
	RTC.INTCTRL = (RTC.INTCTRL & ~(RTC_OVFINTLVL_gm | RTC_COMPINTLVL_gm)) |
	              RTC_OVFINTLVL_OFF_gc | RTC_COMPINTLVL_OFF_gc;
}
