#ifndef _RTC_H_INCLUDED 
#define _RTC_H_INCLUDED

#include <stdio.h>
#include <Arduino.h>
#include <avr/pgmspace.h>


#if !defined(__AVR_XMEGA__)
    #error "Please use external RTC chip"
#endif

typedef void (*RTCCallback_t)(uint32_t time);

typedef struct RTCSettingsStruct
{
	uint32_t setTime;
	RTCCallback_t callback;


	RTCSettingsStruct():
	setTime(0),
	callback(NULL)
	{
	}

	RTCSettingsStruct(
		uint32_t setTime,
		RTCCallback_t callback):
	setTime(setTime),
	callback(callback)
	{
	}

}RTCSettings;

class RTCClass{

public:
	void begin(uint16_t period, uint16_t count, uint16_t compareValue);
	void end();

	RTCClass();
	RTCClass(const RTCSettings &init);

private:
	RTCSettings rtc_settings;

};

extern RTCClass rtc;
#endif
